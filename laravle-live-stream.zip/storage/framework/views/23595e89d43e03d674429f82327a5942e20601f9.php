
<?php $__env->startSection('content'); ?>

    <div>
        <?php $__currentLoopData = $auther; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($a->name); ?> </li>
            <li> <?php echo e($a->email); ?> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo e(route('authors.create')); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front_layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Satyug\Desktop\live-streaming-with-twilio\live-streaming\resources\views/front/showdata.blade.php ENDPATH**/ ?>