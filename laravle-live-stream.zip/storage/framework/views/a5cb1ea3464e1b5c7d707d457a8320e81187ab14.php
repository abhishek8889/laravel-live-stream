
<?php $__env->startSection('content'); ?>
<div class="card p-5">
    <form action="login" method="POST">
        <?php echo csrf_field(); ?>
        <label for="">Name</label> <br>
        <input type="text" name="name">
        <br>
        <label for="">Email</label><br>
        <input type="text" name="email">
        <br>
        <label for="">Password</label><br>
        <input type="text" name="password">
        <input type="submit" value="register">
    </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front_layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Satyug\Desktop\live-streaming-with-twilio\live-streaming\resources\views/front/login.blade.php ENDPATH**/ ?>