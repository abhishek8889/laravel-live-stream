<?php $__env->startSection('content'); ?>
<div class="container border card " style="margin-top:100px;">
<?php if(isset(auth()->user()->name)): ?>
    <div style="padding:50px;">
    <?php echo e("welcome ".auth()->user()->name); ?>

    </div>
    <a href="<?php echo e(route('logout')); ?>" class="btn btn-secondary">Logout</a>
<?php else: ?>
    <?php echo e("login"); ?>

    <a href="<?php echo e(route('login')); ?>"> Go for login -> </a>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front_layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Satyug\Desktop\live-streaming-with-twilio\live-streaming\resources\views/welcome.blade.php ENDPATH**/ ?>