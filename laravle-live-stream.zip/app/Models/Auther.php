<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;

class Auther extends Model
{
    use HasFactory;
    protected $table = "authers";
    protected $guarded = [];
}
