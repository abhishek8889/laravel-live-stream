// Twilio.Video.connect('$TOKEN', {
//     name: 'my-room-name',
//     audio: true,
//     video: { height: 720, frameRate: 24, width: 1280 },
//     bandwidthProfile: {
//     video: {
//         mode: 'grid'
//     }
//     },
//     maxAudioBitrate: 16000, //For music remove this line
//     //For multiparty rooms (participants>=3) uncomment the line below
//     //preferredVideoCodecs: [{ codec: 'VP8', simulcast: true }],
//     networkQuality: {local:1, remote: 1}
// });
console.log('hello');